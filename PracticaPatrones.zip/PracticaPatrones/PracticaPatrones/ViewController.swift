//
//  ViewController.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

