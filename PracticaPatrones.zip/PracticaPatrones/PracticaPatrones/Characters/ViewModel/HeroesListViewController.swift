//
//  HeroesListViewController.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import Foundation
import UIKit


class HeroesListViewController: UIViewController{
        
    var mainView: HeroesListView {self.view as! HeroesListView}

    var heroes:[HeroModel] = []
    var tableViewDataSource: HeroesListTableViewDataSource?
    var viewModel: HeroListViewModel?
    var tableViewDelegate: HeroesListTableViewDelegate?
    
    let boton = UIButton()
   
    override func loadView() {
        view = HeroesListView()
        
      
        tableViewDataSource = HeroesListTableViewDataSource(tableView: mainView.heroesTableView)
        mainView.heroesTableView.dataSource = tableViewDataSource
        
        
        tableViewDelegate = HeroesListTableViewDelegate()
        mainView.heroesTableView.delegate = tableViewDelegate
        
        boton.setTitle("Login", for: .normal)
        view.addSubview(boton)
        boton.backgroundColor = .white
        boton.setTitleColor(.black, for: .normal)
        boton.frame = CGRect(x:300, y:60, width: 80, height: 48)
        boton.addTarget(self, action: #selector(tocarBoton), for: .touchUpInside)
        
        
    }

    
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = HeroListViewModel()
        
        setUpUpdateUI()
        getData()
        setUpTableDelegate()
        

    }
    
    
    //1.- Fin, ir a HeroListViewCell
    func setUpUpdateUI(){

        viewModel?.updateUI = { [weak self] heroes in
            self?.heroes = heroes
            self?.tableViewDataSource?.heroes = heroes
        
        }
        
    }
        
    func getData() {
        viewModel?.fetchData()
        
    }
    
    func setUpTableDelegate(){
    
        
        tableViewDelegate?.didTapOnCell = { [weak self] index in
            
            guard let datasource = self?.tableViewDataSource else {
                return
            }
            
         
            let hero = datasource.heroes[index]
            
            
            let heroDetailViewController = HeroDetailViewController(heroDetailModel: hero)
            
     
            self?.present(heroDetailViewController, animated: true)
            
        }
    }
    
    
    @objc func tocarBoton(){
        let rootVC = LoginViewController()
        let navVC = UINavigationController(rootViewController: rootVC)
        present(navVC, animated: true)
    }
    
    
}
