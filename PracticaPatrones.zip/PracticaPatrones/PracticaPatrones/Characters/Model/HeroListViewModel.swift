//
//  HeroListViewModel.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import Foundation
class HeroListViewModel: NSObject {
    
    var updateUI: ((_ heroes: [HeroModel])-> Void)?
    
   
    
    func fetchData(){
        
        let myToken =  "eyJraWQiOiJwcml2YXRlIiwiYWxnIjoiSFMyNTYiLCJ0eXAiOiJKV1QifQ.eyJleHBpcmF0aW9uIjo2NDA5MjIxMTIwMCwiZW1haWwiOiJhcmlxdWVsbWVAaW5nLnVjc2MuY2wiLCJpZGVudGlmeSI6IjAxRjM4QTc2LUE2NDgtNDI0RC1CMkNELUNEQjJDMUQwMTIyOCJ9.Xh2VhEm2t5u7dsmXa9c6ZRWjhaPMGQ1N2lUsg6eT5Z8"
        

        let apiClient = ApiClient(token: myToken)
        
        apiClient.getHeroes { [weak self] heroes, error in
            self?.updateUI?(heroes)
        }
    }
       
 
    
}
