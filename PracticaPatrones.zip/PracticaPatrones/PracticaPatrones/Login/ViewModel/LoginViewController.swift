//
//  LoginViewController.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    var mainView: LoginView {self.view as! LoginView}
    
    var loginButton : UIButton?
    var emailTextfield : UITextField?
    var passwordTextfield : UITextField?
    var errorMessageView: UILabel?
    
    var viewModel: LoginViewModel?

    override func loadView() {
        let loginView = LoginView()
        
        loginButton = loginView.getLoginButtonView()
        emailTextfield = loginView.getEmailView()
        passwordTextfield = loginView.getPasswordView()
        errorMessageView = loginView.getErrorView()
        
        view = loginView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = LoginViewModel()
        
        loginButton?.addTarget(self, action: #selector(didLoginTapped), for: .touchUpInside)
    }
    
    @objc
    func didLoginTapped(sender: UIButton) {
        
        // 1.- Capturar los valores de texto introducidos en para el email y la password
        
        guard let email = emailTextfield?.text, let password = passwordTextfield?.text else {
            return
        }
        
        // 2.- Prepare the controller to receive data from view model
        
        viewModel?.updateUI = { [weak self] token, error in
            if !token.isEmpty {
                
                DispatchQueue.main.async {
                    self?.errorMessageView?.text = "Bienvenido"
                    self?.presentingViewController?.dismiss(animated: true)
                    
                }
                
            }
            
            
            if !error.isEmpty {
                DispatchQueue.main.async {
                    self?.errorMessageView?.text = error
                }
            }
        }
        
        // 3.- Call view model to perform the login call with the apiClient
        
        viewModel?.login(email: email, password: password)
    }
        
}
