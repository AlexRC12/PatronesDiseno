//
//  LoginViewModel.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import Foundation

class LoginViewModel: NSObject {
    
    var updateUI: ((_ token: String, _ error: String) -> Void)?
    
    func login(email: String, password: String) {
        debugPrint(email)
        debugPrint(password)
        
        ApiClient(token: "").login(user: email, password: password) { [weak self] token, error in
            debugPrint(token ?? "")
            debugPrint(error ?? "")
            
            if let token = token {
                self?.updateUI?(token, "")
                return
            }

            if let error = error {
                self?.updateUI?("", error.localizedDescription)
                return
            }

        }
    }
}
