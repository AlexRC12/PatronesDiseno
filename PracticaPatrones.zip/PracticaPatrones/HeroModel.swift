//
//  HeroModel.swift
//  PracticaPatrones
//
//  Created by Alex Riquelme on 14-02-23.
//

import Foundation

struct HeroModel: Decodable {
  let photo: String
  let id: String
  let favorite: Bool
  let name: String
  let description: String
}
